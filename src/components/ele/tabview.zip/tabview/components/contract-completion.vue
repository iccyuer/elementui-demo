<template>
  <div class="contract-completion">
    <h2>合同完成</h2>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
