<template>
  <div class="contract-termination">
    <h2>合同终止</h2>
    
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
